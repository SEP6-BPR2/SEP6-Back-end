module.exports = {
  transpileDependencies: [
    'vuetify'
  ],
  devServer: {
    host: 'localhost',
    proxy: 'https://lh3.googleusercontent.com',
  }
}
