<template>
  <Container/>
</template>
<script>
import Container from "./layout/Container";

export default {
  name: 'App',

  components: {
    Container,
  },


};
</script>
